﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Практическая_13._2
{
    public partial class Form1 : Form
    {
        private DataGridViewColumn dataGridViewName = null;
        private DataGridViewColumn dataGridViewSurname = null;
        private DataGridViewColumn dataGridViewNumBook = null;
        private string student;
        List<string> studentList = new List<string>();
        static List<Student> classlist = new List<Student>();

        public Form1()
        {
            InitializeComponent();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxSurname_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxBook_TextChanged(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void contextMenuStripDEll_Opening(object sender, CancelEventArgs e)
        {

        }
        private void deleteStudent(int elementIndex)
        {
            DialogResult dialogResult = MessageBox.Show("Вы уверены?", "Нет", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                classlist.RemoveAt(elementIndex);
                dataGridView1.Rows.Clear();
                foreach (Student s in classlist)
                {
                    DataGridViewRow row = new DataGridViewRow();
                    DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell2 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell3 = new DataGridViewTextBoxCell();
                    cell1.ValueType = typeof(string);
                    cell2.ValueType = typeof(string);
                    cell3.ValueType = typeof(int);
                    cell1.Value = s.Enter_name();
                    cell2.Value = s.Enter_surname();
                    cell3.Value = s.Enter_book();
                    row.Cells.Add(cell1);
                    row.Cells.Add(cell2);
                    row.Cells.Add(cell3);
                    dataGridView1.Rows.Add(row);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
                ;
            }            
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxName.Text) && !string.IsNullOrEmpty(textBoxSurname.Text))
            {                              
                Student st = new Student(textBoxName.Text, textBoxSurname.Text, int.Parse(textBoxBook.Text));
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell2 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell3 = new DataGridViewTextBoxCell();
                cell1.ValueType = typeof(string);
                cell2.ValueType = typeof(string);
                cell3.ValueType = typeof(int);
                student = $"{st.Enter_name()} {st.Enter_surname()}";

                if (!studentList.Contains(student))
                {
                    cell1.Value = st.Enter_name();
                    cell2.Value = st.Enter_surname();
                    cell3.Value = st.Enter_book();
                    row.Cells.Add(cell1);
                    row.Cells.Add(cell2);
                    row.Cells.Add(cell3);
                    dataGridView1.Rows.Add(row);
                    textBoxBook.Text = $"{int.Parse(textBoxBook.Text) + 1}";
                    studentList.Add(student);
                    classlist.Add(st);
                }
                else
                {
                   MessageBox.Show("Такой ученик уже записан");
                }               
            }
            else
            {
                MessageBox.Show("Вы не заполнили поля.");
            }
        }

        private void textBoxSurname_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            deleteStudent(dataGridView1.SelectedCells[0].RowIndex);
        }
    }
}
