﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическая_13._2
{
    internal class Student
    {
        string Name_student;
        string Surname_student;
        int Num_book;
        public Student(string name, string surname, int num_book)
        {
            this.Name_student = name;
            this.Surname_student = surname;
            this.Num_book = num_book;
        }      
        public string Enter_name()
        {
            return Name_student;
        }
        public void Set_name(string name)
        {
            Name_student = name;
        }
        public string Enter_surname()
        {
            return Surname_student;
        }
        public void Set_sur(string sur)
        {
            Surname_student = sur;
        }
        public int Enter_book()
        {
            return Num_book;
        }
        public void Set_book(int num)
        {
            Num_book = num;
        }
    }
}
